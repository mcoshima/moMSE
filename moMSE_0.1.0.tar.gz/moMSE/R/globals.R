
utils::globalVariables(c("CM_E", "CM_W", "CPUE.se", "FltSvy", "Label", "REC", "RS_relative", "SpawnBio", "V1", "V2", "V3", "V4", "V5", "V6", "Value", "Year", "Yr", "catch.fleet.year", "index", "obs", "se_log", "seas", "value", "variable", "rep.file", "yr", "year", ".", "Flt", "Catch", "Fleet", "Seas", "error"))
